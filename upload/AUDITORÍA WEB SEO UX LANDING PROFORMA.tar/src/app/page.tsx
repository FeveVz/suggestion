"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import {
  Search,
  Palette,
  Monitor,
  Code,
  FileText,
  Download,
  CheckCircle2,
  ArrowRight,
  Globe,
  BarChart3,
  Eye,
  Layers,
  Sparkles,
  ChevronDown,
  ChevronUp,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const BRAND = {
  orange: "#FF8D00",
  blue: "#00C0FF",
  black: "#000000",
  darkGray: "#696969",
  lightGray: "#D4D4D4",
  white: "#FFFFFF",
};

export default function ProformaPage() {
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);
  const today = new Date();
  const formattedDate = today.toLocaleDateString("es-PE", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });
  const expiryDate = new Date(today.getTime() + 7 * 24 * 60 * 60 * 1000);
  const formattedExpiry = expiryDate.toLocaleDateString("es-PE", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });

  const fadeUp = {
    hidden: { opacity: 0, y: 30 },
    visible: (i: number) => ({
      opacity: 1,
      y: 0,
      transition: { delay: i * 0.1, duration: 0.6, ease: "easeOut" },
    }),
  };

  return (
    <div className="min-h-screen" style={{ background: BRAND.white }}>
      {/* ===== HERO HEADER ===== */}
      <header className="relative overflow-hidden">
        {/* Decorative background elements */}
        <div className="absolute inset-0 pointer-events-none">
          <div
            className="absolute -top-20 -right-20 w-72 h-72 rounded-full opacity-10"
            style={{ background: BRAND.blue }}
          />
          <div
            className="absolute -bottom-10 -left-10 w-48 h-48 rounded-full opacity-10"
            style={{ background: BRAND.orange }}
          />
          <div
            className="absolute top-1/2 right-1/4 w-2 h-2 rounded-full opacity-30"
            style={{ background: BRAND.orange }}
          />
          <div
            className="absolute top-1/3 left-1/3 w-3 h-3 rounded-full opacity-20"
            style={{ background: BRAND.blue }}
          />
        </div>

        <div className="relative max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 pb-10 sm:pt-12 sm:pb-16">
          {/* Agency branding */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
            className="flex items-center gap-3 mb-10 sm:mb-14"
          >
            <img
              src="/logo-suggestion.png"
              alt="Suggestion Logo"
              className="h-8 sm:h-10 w-auto"
            />
            <div className="flex flex-col">
              <span
                className="text-xs sm:text-sm font-medium tracking-[0.2em] uppercase"
                style={{ color: BRAND.darkGray }}
              >
                Agencia de Marketing & Publicidad
              </span>
            </div>
          </motion.div>

          {/* Main title area */}
          <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
            >
              <div className="flex items-center gap-2 mb-3">
                <div
                  className="h-1 w-8 rounded-full"
                  style={{ background: BRAND.orange }}
                />
                <span
                  className="text-xs font-bold tracking-[0.3em] uppercase"
                  style={{ color: BRAND.orange }}
                >
                  Proforma de Servicios
                </span>
              </div>
              <h1
                className="text-3xl sm:text-4xl lg:text-5xl font-black leading-tight"
                style={{ color: BRAND.black }}
              >
                Auditoría{" "}
                <span style={{ color: BRAND.blue }}>SEO</span> +{" "}
                <span style={{ color: BRAND.orange }}>UX</span> +{" "}
                <span style={{ color: BRAND.black }}>Diseño Web</span>
              </h1>
              <p
                className="mt-4 text-sm sm:text-base max-w-lg leading-relaxed"
                style={{ color: BRAND.darkGray }}
              >
                Propuesta profesional integral para potenciar la presencia
                digital de{" "}
                <strong style={{ color: BRAND.black }}>AURA ANDINA</strong>
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="flex flex-col items-end gap-1 text-right"
            >
              <span
                className="text-xs tracking-widest uppercase font-semibold"
                style={{ color: BRAND.darkGray }}
              >
                Código
              </span>
              <span
                className="text-2xl font-black"
                style={{ color: BRAND.black }}
              >
                #SGA-2025-001
              </span>
              <span className="text-xs" style={{ color: BRAND.darkGray }}>
                Fecha de emisión: {formattedDate}
              </span>
              <span className="text-xs" style={{ color: BRAND.darkGray }}>
                Válida hasta: {formattedExpiry}
              </span>
            </motion.div>
          </div>
        </div>
      </header>

      {/* ===== CLIENT INFO BAR ===== */}
      <div
        className="border-y"
        style={{ borderColor: BRAND.lightGray, background: "#FAFAFA" }}
      >
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 sm:gap-12">
            <motion.div
              variants={fadeUp}
              initial="hidden"
              animate="visible"
              custom={0}
            >
              <span
                className="text-[10px] font-bold tracking-[0.25em] uppercase block mb-2"
                style={{ color: BRAND.orange }}
              >
                Cliente
              </span>
              <h3
                className="text-xl sm:text-2xl font-black"
                style={{ color: BRAND.black }}
              >
                AURA ANDINA
              </h3>
              <p className="text-sm mt-1" style={{ color: BRAND.darkGray }}>
                Empresa
              </p>
            </motion.div>
            <motion.div
              variants={fadeUp}
              initial="hidden"
              animate="visible"
              custom={1}
            >
              <span
                className="text-[10px] font-bold tracking-[0.25em] uppercase block mb-2"
                style={{ color: BRAND.blue }}
              >
                Proveedor
              </span>
              <h3
                className="text-xl sm:text-2xl font-black"
                style={{ color: BRAND.black }}
              >
                SUGGESTION
              </h3>
              <p className="text-sm mt-1" style={{ color: BRAND.darkGray }}>
                Agencia de Marketing & Publicidad
              </p>
            </motion.div>
          </div>
        </div>
      </div>

      {/* ===== SERVICE BREAKDOWN ===== */}
      <section className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16">
        <motion.div
          variants={fadeUp}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          custom={0}
          className="mb-10"
        >
          <span
            className="text-[10px] font-bold tracking-[0.25em] uppercase block mb-2"
            style={{ color: BRAND.orange }}
          >
            Alcance del Proyecto
          </span>
          <h2
            className="text-2xl sm:text-3xl font-black"
            style={{ color: BRAND.black }}
          >
            Servicios Incluidos
          </h2>
          <p className="text-sm mt-2 max-w-2xl" style={{ color: BRAND.darkGray }}>
            A continuación detallamos los tres pilares fundamentales de nuestra
            propuesta integral para maximizar el rendimiento digital de Aura
            Andina.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5 sm:gap-6">
          {/* Service 1: SEO */}
          <motion.div
            variants={fadeUp}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            custom={1}
          >
            <Card
              className="h-full border-0 shadow-sm hover:shadow-lg transition-all duration-300 group"
              style={{
                borderTop: `4px solid ${BRAND.blue}`,
                background: BRAND.white,
              }}
            >
              <CardContent className="p-5 sm:p-6">
                <div
                  className="w-12 h-12 rounded-xl flex items-center justify-center mb-4"
                  style={{ background: `${BRAND.blue}15` }}
                >
                  <Search size={22} style={{ color: BRAND.blue }} />
                </div>
                <h3
                  className="text-lg font-bold mb-2"
                  style={{ color: BRAND.black }}
                >
                  Auditoría SEO
                </h3>
                <p
                  className="text-xs leading-relaxed mb-4"
                  style={{ color: BRAND.darkGray }}
                >
                  Análisis exhaustivo del posicionamiento orgánico para
                  maximizar la visibilidad en buscadores.
                </p>
                <ul className="space-y-2">
                  {[
                    "Análisis de palabras clave",
                    "Auditoría técnica on-page",
                    "Evaluación de velocidad de carga",
                    "Análisis de competidores",
                    "Reporte de oportunidades SEO",
                  ].map((item) => (
                    <li
                      key={item}
                      className="flex items-start gap-2 text-xs"
                      style={{ color: BRAND.darkGray }}
                    >
                      <CheckCircle2
                        size={14}
                        className="mt-0.5 shrink-0"
                        style={{ color: BRAND.blue }}
                      />
                      {item}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </motion.div>

          {/* Service 2: UX */}
          <motion.div
            variants={fadeUp}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            custom={2}
          >
            <Card
              className="h-full border-0 shadow-sm hover:shadow-lg transition-all duration-300 group"
              style={{
                borderTop: `4px solid ${BRAND.orange}`,
                background: BRAND.white,
              }}
            >
              <CardContent className="p-5 sm:p-6">
                <div
                  className="w-12 h-12 rounded-xl flex items-center justify-center mb-4"
                  style={{ background: `${BRAND.orange}15` }}
                >
                  <Eye size={22} style={{ color: BRAND.orange }} />
                </div>
                <h3
                  className="text-lg font-bold mb-2"
                  style={{ color: BRAND.black }}
                >
                  Experiencia de Usuario
                </h3>
                <p
                  className="text-xs leading-relaxed mb-4"
                  style={{ color: BRAND.darkGray }}
                >
                  Evaluación de usabilidad y journeys para optimizar la
                  experiencia de navegación.
                </p>
                <ul className="space-y-2">
                  {[
                    "Evaluación de usabilidad (UX Audit)",
                    "Análisis de flujo de navegación",
                    "Identificación de fricciones",
                    "Recomendaciones de mejoras",
                    "Wireframes de soluciones",
                  ].map((item) => (
                    <li
                      key={item}
                      className="flex items-start gap-2 text-xs"
                      style={{ color: BRAND.darkGray }}
                    >
                      <CheckCircle2
                        size={14}
                        className="mt-0.5 shrink-0"
                        style={{ color: BRAND.orange }}
                      />
                      {item}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </motion.div>

          {/* Service 3: Design */}
          <motion.div
            variants={fadeUp}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            custom={3}
          >
            <Card
              className="h-full border-0 shadow-sm hover:shadow-lg transition-all duration-300 group"
              style={{
                borderTop: `4px solid ${BRAND.black}`,
                background: BRAND.white,
              }}
            >
              <CardContent className="p-5 sm:p-6">
                <div
                  className="w-12 h-12 rounded-xl flex items-center justify-center mb-4"
                  style={{ background: `${BRAND.black}08` }}
                >
                  <Palette size={22} style={{ color: BRAND.black }} />
                </div>
                <h3
                  className="text-lg font-bold mb-2"
                  style={{ color: BRAND.black }}
                >
                  Diseño Web
                </h3>
                <p
                  className="text-xs leading-relaxed mb-4"
                  style={{ color: BRAND.darkGray }}
                >
                  Propuesta de rediseño visual profesional alineado con la
                  identidad de marca.
                </p>
                <ul className="space-y-2">
                  {[
                    "Propuesta de diseño visual",
                    "Prototipos de alta fidelidad",
                    "Diseño responsive",
                    "Guía de estilos",
                    "Mockups para implementación",
                  ].map((item) => (
                    <li
                      key={item}
                      className="flex items-start gap-2 text-xs"
                      style={{ color: BRAND.darkGray }}
                    >
                      <CheckCircle2
                        size={14}
                        className="mt-0.5 shrink-0"
                        style={{ color: BRAND.black }}
                      />
                      {item}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </section>

      {/* ===== METHODOLOGY SECTION ===== */}
      <section
        className="relative"
        style={{
          background: BRAND.black,
        }}
      >
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16">
          <motion.div
            variants={fadeUp}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            custom={0}
            className="mb-10"
          >
            <span
              className="text-[10px] font-bold tracking-[0.25em] uppercase block mb-2"
              style={{ color: BRAND.orange }}
            >
              Proceso
            </span>
            <h2 className="text-2xl sm:text-3xl font-black" style={{ color: BRAND.white }}>
              Nuestra Metodología
            </h2>
          </motion.div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                step: "01",
                title: "Diagnóstico",
                desc: "Auditoría completa del sitio actual, SEO técnico y análisis de UX.",
                icon: <BarChart3 size={20} />,
              },
              {
                step: "02",
                title: "Estrategia",
                desc: "Definición de objetivos, keyword mapping y plan de acción personalizado.",
                icon: <Layers size={20} />,
              },
              {
                step: "03",
                title: "Diseño",
                desc: "Creación de prototipos, wireframes y mockups de alta fidelidad.",
                icon: <Sparkles size={20} />,
              },
              {
                step: "04",
                title: "Entrega",
                desc: "Documentación completa, guías de implementación y soporte.",
                icon: <FileText size={20} />,
              },
            ].map((phase, i) => (
              <motion.div
                key={phase.step}
                variants={fadeUp}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true }}
                custom={i + 1}
                className="relative"
              >
                <div className="flex items-center gap-3 mb-3">
                  <div
                    className="w-10 h-10 rounded-lg flex items-center justify-center"
                    style={{
                      background:
                        i === 0
                          ? `${BRAND.blue}25`
                          : i === 1
                            ? `${BRAND.orange}25`
                            : i === 2
                              ? `${BRAND.white}10`
                              : `${BRAND.blue}15`,
                    }}
                  >
                    <span style={{ color: i % 2 === 0 ? BRAND.blue : BRAND.orange }}>
                      {phase.icon}
                    </span>
                  </div>
                  <div>
                    <span
                      className="text-[10px] font-mono tracking-widest"
                      style={{ color: BRAND.darkGray }}
                    >
                      PASO {phase.step}
                    </span>
                  </div>
                </div>
                <h4
                  className="text-base font-bold mb-1"
                  style={{ color: BRAND.white }}
                >
                  {phase.title}
                </h4>
                <p className="text-xs leading-relaxed" style={{ color: "#999" }}>
                  {phase.desc}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ===== PRICING SECTION ===== */}
      <section className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16">
        <motion.div
          variants={fadeUp}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          custom={0}
          className="text-center mb-10"
        >
          <span
            className="text-[10px] font-bold tracking-[0.25em] uppercase block mb-2"
            style={{ color: BRAND.orange }}
          >
            Inversión
          </span>
          <h2
            className="text-2xl sm:text-3xl font-black"
            style={{ color: BRAND.black }}
          >
            Planes Disponibles
          </h2>
          <p className="text-sm mt-2 max-w-xl mx-auto" style={{ color: BRAND.darkGray }}>
            Seleccione el plan que mejor se adapte a las necesidades de su
            negocio. Ambos incluyen la auditoría integral completa.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-3xl mx-auto">
          {/* Plan 1: Only Audit + Design */}
          <motion.div
            variants={fadeUp}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            custom={1}
          >
            <Card
              className={`h-full border-2 transition-all duration-300 cursor-pointer relative overflow-hidden ${
                selectedPlan === "basic"
                  ? "shadow-xl scale-[1.02]"
                  : "shadow-sm hover:shadow-md"
              }`}
              style={{
                borderColor:
                  selectedPlan === "basic" ? BRAND.blue : BRAND.lightGray,
                background: BRAND.white,
              }}
              onClick={() => setSelectedPlan("basic")}
            >
              {selectedPlan === "basic" && (
                <div
                  className="absolute top-0 right-0 px-3 py-1 text-[10px] font-bold text-white tracking-wider uppercase rounded-bl-lg"
                  style={{ background: BRAND.blue }}
                >
                  Seleccionado
                </div>
              )}
              <CardContent className="p-6 sm:p-8">
                <div className="flex items-center gap-2 mb-4">
                  <FileText size={18} style={{ color: BRAND.blue }} />
                  <span
                    className="text-sm font-bold tracking-wide"
                    style={{ color: BRAND.blue }}
                  >
                    PLAN BÁSICO
                  </span>
                </div>
                <h3
                  className="text-lg font-bold mb-1"
                  style={{ color: BRAND.black }}
                >
                  Auditoría + Propuesta
                </h3>
                <p
                  className="text-xs mb-6 leading-relaxed"
                  style={{ color: BRAND.darkGray }}
                >
                  Recibes la auditoría completa SEO/UX/Diseño con toda la
                  documentación para que tu equipo implemente los cambios.
                </p>

                <div className="mb-6">
                  <div className="flex items-baseline gap-1">
                    <span
                      className="text-4xl sm:text-5xl font-black"
                      style={{ color: BRAND.black }}
                    >
                      S/ 600
                    </span>
                    <span
                      className="text-sm"
                      style={{ color: BRAND.darkGray }}
                    >
                      /proyecto
                    </span>
                  </div>
                </div>

                <Separator className="my-5" style={{ background: BRAND.lightGray }} />

                <ul className="space-y-3">
                  {[
                    "Auditoría SEO completa",
                    "Evaluación UX profesional",
                    "Propuesta de diseño web",
                    "Reporte detallado PDF",
                    "Guía de implementación",
                  ].map((item) => (
                    <li
                      key={item}
                      className="flex items-start gap-2 text-xs"
                      style={{ color: BRAND.darkGray }}
                    >
                      <CheckCircle2
                        size={14}
                        className="mt-0.5 shrink-0"
                        style={{ color: BRAND.blue }}
                      />
                      {item}
                    </li>
                  ))}
                  <li
                    className="flex items-start gap-2 text-xs opacity-40"
                    style={{ color: BRAND.darkGray }}
                  >
                    <span className="mt-0.5 shrink-0 inline-block w-3.5 h-3.5 rounded-full border" />
                    Implementación y reedición
                  </li>
                </ul>
              </CardContent>
            </Card>
          </motion.div>

          {/* Plan 2: Audit + Design + Implementation */}
          <motion.div
            variants={fadeUp}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            custom={2}
          >
            <Card
              className={`h-full border-2 transition-all duration-300 cursor-pointer relative overflow-hidden ${
                selectedPlan === "full"
                  ? "shadow-xl scale-[1.02]"
                  : "shadow-sm hover:shadow-md"
              }`}
              style={{
                borderColor:
                  selectedPlan === "full" ? BRAND.orange : BRAND.lightGray,
                background: BRAND.white,
              }}
              onClick={() => setSelectedPlan("full")}
            >
              {selectedPlan === "full" && (
                <div
                  className="absolute top-0 right-0 px-3 py-1 text-[10px] font-bold text-white tracking-wider uppercase rounded-bl-lg"
                  style={{ background: BRAND.orange }}
                >
                  Seleccionado
                </div>
              )}
              {/* Recommended badge */}
              {selectedPlan !== "full" && (
                <div className="absolute top-0 right-0 px-3 py-1 text-[10px] font-bold tracking-wider uppercase rounded-bl-lg border"
                  style={{
                    color: BRAND.orange,
                    borderColor: `${BRAND.orange}40`,
                    background: `${BRAND.orange}08`,
                  }}
                >
                  Recomendado
                </div>
              )}
              <CardContent className="p-6 sm:p-8">
                <div className="flex items-center gap-2 mb-4">
                  <Code size={18} style={{ color: BRAND.orange }} />
                  <span
                    className="text-sm font-bold tracking-wide"
                    style={{ color: BRAND.orange }}
                  >
                    PLAN FULL
                  </span>
                </div>
                <h3
                  className="text-lg font-bold mb-1"
                  style={{ color: BRAND.black }}
                >
                  Auditoría + Implementación
                </h3>
                <p
                  className="text-xs mb-6 leading-relaxed"
                  style={{ color: BRAND.darkGray }}
                >
                  Incluye todo lo del Plan Básico más la reedición e
                  implementación completa de la página web por nuestro equipo.
                </p>

                <div className="mb-6">
                  <div className="flex items-baseline gap-1">
                    <span
                      className="text-4xl sm:text-5xl font-black"
                      style={{ color: BRAND.black }}
                    >
                      S/ 1,000
                    </span>
                    <span
                      className="text-sm"
                      style={{ color: BRAND.darkGray }}
                    >
                      /proyecto
                    </span>
                  </div>
                </div>

                <Separator className="my-5" style={{ background: BRAND.lightGray }} />

                <ul className="space-y-3">
                  {[
                    "Auditoría SEO completa",
                    "Evaluación UX profesional",
                    "Propuesta de diseño web",
                    "Reporte detallado PDF",
                    "Guía de implementación",
                    "Reedición de la página web",
                    "Implementación de cambios",
                    "Pruebas de calidad",
                  ].map((item, idx) => (
                    <li
                      key={item}
                      className="flex items-start gap-2 text-xs"
                      style={{ color: BRAND.darkGray }}
                    >
                      <CheckCircle2
                        size={14}
                        className="mt-0.5 shrink-0"
                        style={{
                          color: idx >= 5 ? BRAND.orange : BRAND.blue,
                        }}
                      />
                      {item}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Comparison note */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5 }}
          className="mt-8 text-center"
        >
          <div
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full text-xs font-medium"
            style={{
              background: `${BRAND.black}05`,
              color: BRAND.darkGray,
            }}
          >
            <Globe size={14} />
            La diferencia de S/ 400 incluye la implementación completa y
            reedición del sitio web
          </div>
        </motion.div>
      </section>

      {/* ===== DETAILED BREAKDOWN TABLE ===== */}
      <section
        className="border-y"
        style={{
          borderColor: BRAND.lightGray,
          background: "#FAFAFA",
        }}
      >
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-14">
          <motion.div
            variants={fadeUp}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            custom={0}
            className="mb-8"
          >
            <span
              className="text-[10px] font-bold tracking-[0.25em] uppercase block mb-2"
              style={{ color: BRAND.blue }}
            >
              Detalle
            </span>
            <h2
              className="text-2xl sm:text-3xl font-black"
              style={{ color: BRAND.black }}
            >
              Desglose de Inversión
            </h2>
          </motion.div>

          {/* Table */}
          <div
            className="rounded-xl overflow-hidden border"
            style={{ borderColor: BRAND.lightGray }}
          >
            {/* Table header */}
            <div
              className="grid grid-cols-12 gap-2 px-4 sm:px-6 py-3 text-[10px] font-bold tracking-widest uppercase"
              style={{
                background: BRAND.black,
                color: BRAND.white,
              }}
            >
              <div className="col-span-1 hidden sm:block">Item</div>
              <div className="col-span-5 sm:col-span-4">Servicio</div>
              <div className="col-span-4 sm:col-span-4 text-center">
                Descripción
              </div>
              <div className="col-span-3 text-right">Valor</div>
            </div>

            {/* Row 1 */}
            <div
              className="grid grid-cols-12 gap-2 px-4 sm:px-6 py-4 text-xs border-b items-center"
              style={{
                borderColor: BRAND.lightGray,
                color: BRAND.darkGray,
                background: BRAND.white,
              }}
            >
              <div className="col-span-1 hidden sm:block font-mono text-[10px]">
                01
              </div>
              <div
                className="col-span-5 sm:col-span-4 font-semibold text-sm"
                style={{ color: BRAND.black }}
              >
                Auditoría SEO
              </div>
              <div className="col-span-4 sm:col-span-4 text-center">
                Análisis técnico y reporte
              </div>
              <div
                className="col-span-3 text-right font-bold"
                style={{ color: BRAND.black }}
              >
                S/ 200
              </div>
            </div>

            {/* Row 2 */}
            <div
              className="grid grid-cols-12 gap-2 px-4 sm:px-6 py-4 text-xs border-b items-center"
              style={{
                borderColor: BRAND.lightGray,
                color: BRAND.darkGray,
                background: "#F8F8F8",
              }}
            >
              <div className="col-span-1 hidden sm:block font-mono text-[10px]">
                02
              </div>
              <div
                className="col-span-5 sm:col-span-4 font-semibold text-sm"
                style={{ color: BRAND.black }}
              >
                Evaluación UX
              </div>
              <div className="col-span-4 sm:col-span-4 text-center">
                Auditoría de experiencia de usuario
              </div>
              <div
                className="col-span-3 text-right font-bold"
                style={{ color: BRAND.black }}
              >
                S/ 200
              </div>
            </div>

            {/* Row 3 */}
            <div
              className="grid grid-cols-12 gap-2 px-4 sm:px-6 py-4 text-xs border-b items-center"
              style={{
                borderColor: BRAND.lightGray,
                color: BRAND.darkGray,
                background: BRAND.white,
              }}
            >
              <div className="col-span-1 hidden sm:block font-mono text-[10px]">
                03
              </div>
              <div
                className="col-span-5 sm:col-span-4 font-semibold text-sm"
                style={{ color: BRAND.black }}
              >
                Diseño Web
              </div>
              <div className="col-span-4 sm:col-span-4 text-center">
                Prototipos y mockups
              </div>
              <div
                className="col-span-3 text-right font-bold"
                style={{ color: BRAND.black }}
              >
                S/ 200
              </div>
            </div>

            {/* Row 4 - optional */}
            <div
              className="grid grid-cols-12 gap-2 px-4 sm:px-6 py-4 text-xs border-b items-center"
              style={{
                borderColor: BRAND.lightGray,
                color: BRAND.darkGray,
                background: "#F8F8F8",
              }}
            >
              <div className="col-span-1 hidden sm:block font-mono text-[10px]">
                04
              </div>
              <div className="col-span-5 sm:col-span-4 flex items-center gap-2">
                <span
                  className="font-semibold text-sm"
                  style={{ color: BRAND.black }}
                >
                  Reedición e Implementación
                </span>
                <span
                  className="text-[9px] font-bold px-1.5 py-0.5 rounded tracking-wider uppercase"
                  style={{
                    background: `${BRAND.orange}15`,
                    color: BRAND.orange,
                  }}
                >
                  Opcional
                </span>
              </div>
              <div className="col-span-4 sm:col-span-4 text-center">
                Desarrollo completo
              </div>
              <div
                className="col-span-3 text-right font-bold"
                style={{ color: BRAND.black }}
              >
                S/ 400
              </div>
            </div>

            {/* Totals */}
            <div
              className="grid grid-cols-12 gap-2 px-4 sm:px-6 py-4 items-center"
              style={{ background: BRAND.white }}
            >
              <div className="col-span-6 sm:col-span-5">
                <span
                  className="text-sm font-bold"
                  style={{ color: BRAND.black }}
                >
                  PLAN BÁSICO (01-03)
                </span>
              </div>
              <div className="col-span-4 sm:col-span-4 text-center">
                <span className="text-xs" style={{ color: BRAND.darkGray }}>
                  Auditoría + Propuesta
                </span>
              </div>
              <div
                className="col-span-2 sm:col-span-3 text-right text-lg font-black"
                style={{ color: BRAND.blue }}
              >
                S/ 600
              </div>
            </div>
            <div
              className="grid grid-cols-12 gap-2 px-4 sm:px-6 py-4 items-center"
              style={{ background: "#FAFAFA" }}
            >
              <div className="col-span-6 sm:col-span-5">
                <span
                  className="text-sm font-bold"
                  style={{ color: BRAND.black }}
                >
                  PLAN FULL (01-04)
                </span>
              </div>
              <div className="col-span-4 sm:col-span-4 text-center">
                <span className="text-xs" style={{ color: BRAND.darkGray }}>
                  + Implementación
                </span>
              </div>
              <div
                className="col-span-2 sm:col-span-3 text-right text-lg font-black"
                style={{ color: BRAND.orange }}
              >
                S/ 1,000
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ===== DELIVERY TIMELINE ===== */}
      <section className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-14">
        <motion.div
          variants={fadeUp}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          custom={0}
          className="mb-8"
        >
          <span
            className="text-[10px] font-bold tracking-[0.25em] uppercase block mb-2"
            style={{ color: BRAND.blue }}
          >
            Tiempos
          </span>
          <h2
            className="text-2xl sm:text-3xl font-black"
            style={{ color: BRAND.black }}
          >
            Cronograma de Entrega
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 max-w-3xl">
          {[
            {
              phase: "Semana 1",
              title: "Diagnóstico",
              desc: "Auditoría SEO y evaluación UX del sitio actual",
              color: BRAND.blue,
            },
            {
              phase: "Semana 2",
              title: "Diseño",
              desc: "Propuesta de diseño y prototipos de alta fidelidad",
              color: BRAND.orange,
            },
            {
              phase: "Semana 3+",
              title: "Entrega",
              desc: "Documentación final y entrega de reporte completo",
              color: BRAND.black,
            },
          ].map((item, i) => (
            <motion.div
              key={item.phase}
              variants={fadeUp}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              custom={i + 1}
              className="relative"
            >
              <div
                className="h-full p-5 rounded-xl border"
                style={{
                  borderColor: `${item.color}20`,
                  background: `${item.color}04`,
                }}
              >
                <span
                  className="text-[10px] font-bold tracking-widest uppercase"
                  style={{ color: item.color }}
                >
                  {item.phase}
                </span>
                <h4
                  className="text-base font-bold mt-1 mb-2"
                  style={{ color: BRAND.black }}
                >
                  {item.title}
                </h4>
                <p
                  className="text-xs leading-relaxed"
                  style={{ color: BRAND.darkGray }}
                >
                  {item.desc}
                </p>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="mt-6 max-w-3xl"
        >
          <div
            className="flex items-center gap-2 px-4 py-3 rounded-lg text-xs"
            style={{
              background: `${BRAND.orange}08`,
              color: BRAND.darkGray,
              borderLeft: `3px solid ${BRAND.orange}`,
            }}
          >
            <Monitor size={14} className="shrink-0" style={{ color: BRAND.orange }} />
            <span>
              <strong style={{ color: BRAND.black }}>Nota:</strong> Si se
              selecciona el Plan Full, las semanas de implementación se
              agregarán al cronograma según la complejidad del proyecto.
            </span>
          </div>
        </motion.div>
      </section>

      {/* ===== TERMS & CONDITIONS ===== */}
      <section
        className="border-t"
        style={{
          borderColor: BRAND.lightGray,
          background: "#FAFAFA",
        }}
      >
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-14">
          <motion.div
            variants={fadeUp}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            custom={0}
            className="mb-6"
          >
            <span
              className="text-[10px] font-bold tracking-[0.25em] uppercase block mb-2"
              style={{ color: BRAND.darkGray }}
            >
              Condiciones
            </span>
            <h2
              className="text-xl sm:text-2xl font-black"
              style={{ color: BRAND.black }}
            >
              Términos y Condiciones
            </h2>
          </motion.div>

          <div className="max-w-3xl">
            <Accordion
              type="single"
              collapsible
              className="space-y-2"
            >
              {[
                {
                  q: "Forma de pago",
                  a: "El 50% al inicio del proyecto y el 50% restante al momento de la entrega final. Se acepta transferencia bancaria o Yape/Plin.",
                },
                {
                  q: "Tiempo de ejecución",
                  a: "El plazo estimado es de 2 a 3 semanas para el Plan Básico y de 4 a 6 semanas para el Plan Full, sujeto a la disponibilidad de información por parte del cliente.",
                },
                {
                  q: "Alcance del servicio",
                  a: "La presente proforma cubre una página web principal. Cualquier funcionalidad adicional, página extra o integración de terceros se cotizará por separado.",
                },
                {
                  q: "Garantía",
                  a: "Ofrecemos hasta 2 rondas de revisiones sin costo adicional. Las revisiones posteriores se cotizarán de acuerdo a la complejidad de los cambios solicitados.",
                },
                {
                  q: "Propiedad intelectual",
                  a: "Al completar el pago total, el cliente adquiere todos los derechos de propiedad intelectual sobre los entregables finales del proyecto.",
                },
              ].map((item, i) => (
                <AccordionItem
                  key={i}
                  value={`item-${i}`}
                  className="border rounded-lg px-1"
                  style={{ borderColor: BRAND.lightGray, background: BRAND.white }}
                >
                  <AccordionTrigger className="text-xs sm:text-sm font-semibold px-4 py-3 hover:no-underline text-left">
                    <span style={{ color: BRAND.black }}>{item.q}</span>
                  </AccordionTrigger>
                  <AccordionContent className="px-4 pb-4 text-xs leading-relaxed" style={{ color: BRAND.darkGray }}>
                    {item.a}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        </div>
      </section>

      {/* ===== CTA SECTION ===== */}
      <section className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16">
        <motion.div
          variants={fadeUp}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          custom={0}
          className="relative rounded-2xl overflow-hidden p-8 sm:p-12 text-center"
          style={{ background: BRAND.black }}
        >
          {/* Decorative elements */}
          <div className="absolute inset-0 pointer-events-none">
            <div
              className="absolute -top-10 -right-10 w-40 h-40 rounded-full opacity-10"
              style={{ background: BRAND.blue }}
            />
            <div
              className="absolute -bottom-8 -left-8 w-32 h-32 rounded-full opacity-10"
              style={{ background: BRAND.orange }}
            />
          </div>

          <div className="relative">
            <div className="flex justify-center mb-4">
              <div className="flex gap-1">
                <div
                  className="w-2 h-2 rounded-full"
                  style={{ background: BRAND.blue }}
                />
                <div
                  className="w-2 h-2 rounded-full"
                  style={{ background: BRAND.orange }}
                />
                <div
                  className="w-2 h-2 rounded-full"
                  style={{ background: BRAND.white }}
                />
              </div>
            </div>

            <h2 className="text-2xl sm:text-3xl font-black mb-3" style={{ color: BRAND.white }}>
              ¿Listo para impulsar tu presencia digital?
            </h2>
            <p className="text-sm max-w-md mx-auto mb-8" style={{ color: "#999" }}>
              Confirma tu selección y nos pondremos en contacto contigo para
              comenzar a trabajar en el proyecto de Aura Andina.
            </p>

            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <Button
                size="lg"
                className="rounded-full px-8 font-bold text-sm gap-2 transition-all duration-300 hover:scale-105"
                style={{
                  background: BRAND.orange,
                  color: BRAND.white,
                }}
              >
                <ArrowRight size={16} />
                Aceptar Propuesta
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="rounded-full px-8 font-bold text-sm gap-2 transition-all duration-300"
                style={{
                  borderColor: `${BRAND.white}30`,
                  color: BRAND.white,
                  background: "transparent",
                }}
              >
                <Download size={16} />
                Descargar PDF
              </Button>
            </div>
          </div>
        </motion.div>
      </section>

      {/* ===== FOOTER ===== */}
      <footer
        className="border-t"
        style={{ borderColor: BRAND.lightGray }}
      >
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <img
                src="/logo-suggestion.png"
                alt="Suggestion"
                className="h-6 w-auto opacity-60"
              />
              <span className="text-[10px] tracking-widest uppercase" style={{ color: BRAND.darkGray }}>
                Suggestion — Agencia de Marketing & Publicidad
              </span>
            </div>
            <div className="flex items-center gap-4">
              <span className="text-[10px]" style={{ color: BRAND.lightGray }}>
                Proforma #SGA-2025-001
              </span>
              <div className="flex gap-1">
                <div
                  className="w-1.5 h-1.5 rounded-full"
                  style={{ background: BRAND.blue }}
                />
                <div
                  className="w-1.5 h-1.5 rounded-full"
                  style={{ background: BRAND.orange }}
                />
                <div
                  className="w-1.5 h-1.5 rounded-full"
                  style={{ background: BRAND.black }}
                />
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
